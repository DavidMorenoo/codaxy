package com.example.myfirstjob.persistence;

public class OfferFile extends FileOperations {

    //Methods

    /**
     * Constructor OfferFile
     */
    public OfferFile() {
        setDirectory("offerFile");
    }


}
